#!/bin/bash

# Definir o caminho do arquivo
CONFIG_FILE="/userdata/system/configs/emulationstation/es_systems_j2me.cfg"

# Verificar se o arquivo existe
if [ ! -f "$CONFIG_FILE" ]; then
  echo "Arquivo de configuração não encontrado: $CONFIG_FILE"
  exit 1
fi

# Definir o conteúdo para a primeira execução
CONTENT_1='<?xml version="1.0"?>
<systemList>
  <system>
        <fullname>Java ME</fullname>
        <name>j2me</name>
        <manufacturer>Oracle</manufacturer>
        <release>2005</release>
        <hardware>portable</hardware>
        <path>/userdata/roms/j2me</path>
        <extension>.jar .JAR</extension>
        <command>/opt/Freej2me/freej2me.sh %ROM%</command>
        <platform>j2me</platform>
        <theme>j2me</theme>
        <emulators>
            <emulator name="libretro">
                <cores>
                    <core default="true">freej2me</core>
                </cores>
            </emulator>
        </emulators>
  </system>
</systemList>'

# Definir o conteúdo para a segunda execução
CONTENT_2='<?xml version="1.0"?>
<systemList>
  <system>
        <fullname>Java ME</fullname>
        <name>j2me</name>
        <manufacturer>Oracle</manufacturer>
        <release>2005</release>
        <hardware>portable</hardware>
        <path>/userdata/roms/j2me</path>
        <extension>.jar .JAR</extension>
        <command>/opt/Freej2me/freej2me2.sh %ROM%</command>
        <platform>j2me</platform>
        <theme>j2me</theme>
        <emulators>
            <emulator name="libretro">
                <cores>
                    <core default="true">freej2me</core>
                </cores>
            </emulator>
        </emulators>
  </system>
</systemList>'

# Verificar o conteúdo atual do arquivo e alternar entre os conteúdos
if grep -q "/opt/Freej2me/freej2me.sh" "$CONFIG_FILE"; then
  echo "$CONTENT_2" > "$CONFIG_FILE"
else
  echo "$CONTENT_1" > "$CONFIG_FILE"
fi

echo "Configuração atualizada com sucesso."

# Reiniciar o EmulationStation para aplicar as novas configurações
chmod 777 /userdata/system/configs/emulationstation/es_systems_j2me.cfg
killall -9 emulationstation

echo "EmulationStation reiniciado para aplicar as novas configurações."