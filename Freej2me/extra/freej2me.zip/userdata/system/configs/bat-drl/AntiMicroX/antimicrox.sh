#!/bin/bash
export QT_QPA_PLATFORM=xcb
exec /userdata/system/configs/bat-drl/AntiMicroX/antimicrox "$@"
