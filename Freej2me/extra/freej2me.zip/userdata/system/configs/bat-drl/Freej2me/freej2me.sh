#!/bin/sh
ROM="file://${1}"
SAVE_DIR='/userdata/saves/j2me'
FREJ2ME_DIR="$(dirname ${0})"
JAVA_HOME="/userdata/system/configs/bat-drl/java"
CLASSPATH="${JAVA_HOME}/lib/tools.jar"
PATH="${PATH}:${JAVA_HOME}/bin"
export JAVA_HOME PATH CLASSPATH
emulatorlauncher -p1index 0 -p1guid 19000000010000000100000000010000 -p1name Deeplay-keys -p1nbbuttons 17 -p1nbhats 1 -p1nbaxes 4 -p1devicepath /dev/input/event1 -system j2me -rom "$1" -gameinfoxml /tmp/game.xml -systemname JavaME

#emulatorlauncher %CONTROLLERSCONFIG% -system %SYSTEM% -rom %ROM% -gameinfoxml %GAMEINFOXML% -systemname %SYSTEMNAME%