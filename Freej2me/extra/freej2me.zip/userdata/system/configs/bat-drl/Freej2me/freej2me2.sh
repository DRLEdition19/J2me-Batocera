#!/bin/sh
ROM="file://${1}"
SAVE_DIR='/userdata/saves/j2me'
FREJ2ME_DIR="$(dirname ${0})"
JAVA_HOME="/userdata/system/configs/bat-drl/java"
CLASSPATH="${JAVA_HOME}/lib/tools.jar"
PATH="${PATH}:${JAVA_HOME}/bin"
export JAVA_HOME PATH CLASSPATH
#emulatorlauncher -p1index 0 -p1guid 19000000010000000100000000010000 -p1name Deeplay-keys -p1nbbuttons 17 -p1nbhats 1 -p1nbaxes 4 -p1devicepath /dev/input/event1 -system j2me -rom "$1" -gameinfoxml /tmp/game.xml -systemname JavaME

mkdir -p "${SAVE_DIR}"

### Inicia o AntiMicroX ###

if [ -e '/dev/input/js0' ]; then
    antimicrox --hidden --profile /userdata/system/configs/bat-drl/Freej2me/config/j2me.joystick.amgp &
    ANTIMICROX_PID=$!
fi

### Executa o jogo

java -Dsun.java2d.opengl=True -jar "${FREJ2ME_DIR}/freej2me.jar" "${ROM}"

### Encerra o AntiMicroX ###

if [ -n "${ANTIMICROX_PID}" ]; then
    kill -9 "${ANTIMICROX_PID}"
fi

exit 0